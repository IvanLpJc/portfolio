export 'package:portfolio/ui/pages/about_page.dart';
export 'package:portfolio/ui/pages/certifications_page.dart';
export 'package:portfolio/ui/pages/contact_page.dart';
export 'package:portfolio/ui/pages/home_page.dart';
export 'package:portfolio/ui/pages/intro/intro_page.dart';
export 'package:portfolio/ui/pages/works_page.dart';
