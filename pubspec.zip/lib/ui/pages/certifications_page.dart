import 'package:flutter/material.dart';
import 'package:portfolio/values/constants.dart';

class CertificationsPage extends StatelessWidget {
  static const String route = StringConst.certificationsPage; 

  const CertificationsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}